package algo;

public class RR 
{
    // Method to find the waiting time for all
    // processes
    static void findWaitingTime(int processes[], int n,
                 int burstt[], int waitingt[], int quantum)
    {
        // Make a copy of burst times burstt[] to store remaining
        // burst times.
        int rem_burstt[] = new int[n];
        for (int i = 0 ; i < n ; i++)
            rem_burstt[i] =  burstt[i];
       
        int t = 0; // Current time
       
        // Keep traversing processes in round robin manner
        // until all of them are not done.
        while(true)
        {
            boolean done = true;
       
            // Traverse all processes one by one repeatedly
            for (int i = 0 ; i < n; i++)
            {
                // If burst time of a process is greater than 0
                // then only need to process further
                if (rem_burstt[i] > 0)
                {
                    done = false; // There is a pending process
       
                    if (rem_burstt[i] > quantum)
                    {
                        // Increase the value of t i.e. shows
                        // how much time a process has been processed
                        t += quantum;
       
                        // Decrease the burst_time of current process
                        // by quantum
                        rem_burstt[i] -= quantum;
                    }
       
                    // If burst time is smaller than or equal to
                    // quantum. Last cycle for this process
                    else
                    {
                        // Increase the value of t i.e. shows
                        // how much time a process has been processed
                        t = t + rem_burstt[i];
       
                        // Waiting time is current time minus time
                        // used by this process
                        waitingt[i] = t - burstt[i];
       
                        // As the process gets fully executed
                        // make its remaining burst time = 0
                        rem_burstt[i] = 0;
                    }
                }
            }
       
            // If all processes are done
            if (done == true)
              break;
        }
    }
       
    // Method to calculate turn around time
    static void findTurnAroundTime(int processes[], int n,
                            int burstt[], int waitingt[], int tatime[])
    {
        // calculating turnaround time by adding
        // burstt[i] + waitingt[i]
        for (int i = 0; i < n ; i++)
            tatime[i] = burstt[i] + waitingt[i];
    }
       
    // Method to calculate average time
    static void findavgTime(int processes[], int n, int burstt[],
                                         int quantum)
    {
        int waitingt[] = new int[n], tatime[] = new int[n];
        int total_waitingt = 0, total_tat = 0;
       
        // Function to find waiting time of all processes
        findWaitingTime(processes, n, burstt, waitingt, quantum);
       
        // Function to find turn around time for all processes
        findTurnAroundTime(processes, n, burstt, waitingt, tatime);
       
        // Display processes along with all details
        System.out.println("Processes " + " Burst time " +
                      " Waiting time " + " Turn around time");
       
        // Calculate total waiting time and total turn
        // around time
        for (int i=0; i<n; i++)
        {
            total_waitingt = total_waitingt + waitingt[i];
            total_tat = total_tat + tatime[i];
            System.out.println(" " + (i+1) + "\t\t" + burstt[i] +"\t " +
                              waitingt[i] +"\t\t " + tatime[i]);
        }
       
        System.out.println("Average waiting time = " +
                          (float)total_waitingt / (float)n);
        System.out.println("Average turn around time = " +
                           (float)total_tat / (float)n);
    }
      
    // Driver Method
    public static void main(String[] args)
    {
        // process id's
        int processes[] = { 1, 2, 3};
        int n = processes.length;
       
        // Burst time of all processes
        int burst_time[] = {10, 5, 8};
       
        // Time quantum
        int quantum = 2;
        findavgTime(processes, n, burst_time, quantum);
    }
}